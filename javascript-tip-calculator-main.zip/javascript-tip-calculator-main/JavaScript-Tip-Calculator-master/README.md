# Tip Calculator

Tip Calculator created using JavaScript, HTML5 ,and CSS3 to help determine how much to tip at restaurants or whenever the need arises.
